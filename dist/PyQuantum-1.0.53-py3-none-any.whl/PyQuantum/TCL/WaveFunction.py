from PyQuantum.TC.WaveFunction import *
